# Progression

The progression model should feel familiar to players who enjoy tabletop-inspired role progression without becoming a strict tabletop simulator.

Starter assumptions:

- characters have a species, class, and optional subclass path
- leveling should modify core stats and unlock future features
- subclasses should branch identity without requiring a full rewrite of the base class
- equipment and crafted items should matter alongside level

Framework Prototype v0.1 only needs:

- base stats list
- level cap placeholder
- class and subclass data
- starter equipment assumptions
