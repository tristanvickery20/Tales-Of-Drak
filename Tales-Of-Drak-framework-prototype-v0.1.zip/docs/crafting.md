# Crafting

Crafting should connect naturally to gathering and equipment progression.

Framework Prototype v0.1 only needs:

- gathering node definitions
- crafting recipe definitions
- item references by ID
- placeholder station tags

Simple design rules:

- recipes consume item IDs
- outputs create item IDs
- station requirements stay lightweight
- do not hardcode recipes into scripts
