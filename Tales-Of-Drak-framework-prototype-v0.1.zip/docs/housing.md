# Housing

Housing should support a modest player-building loop, not a full sandbox survival game.

Framework Prototype v0.1 only needs snapping build piece definitions and structural placeholders.

Goals:

- build pieces use clear snap categories
- pieces can be defined through data first
- a future Godot placement system can read those definitions
- the system should support small homes, camps, and utility structures

Not yet in scope:

- structural integrity simulation
- territory control
- large settlement management
- networked persistence
