# Systems

Place modular gameplay systems here.

Good future candidates:

- progression
- inventory
- equipment
- crafting
- gathering
- housing snapping
- dungeon flow

Keep system boundaries clear so contributors can work in parallel.
