# Scripts

Place reusable GDScript files here.

Suggested future structure:

- `characters/`
- `inventory/`
- `combat/`
- `crafting/`
- `building/`
- `helpers/`

Prefer small scripts by responsibility instead of giant controller scripts.
