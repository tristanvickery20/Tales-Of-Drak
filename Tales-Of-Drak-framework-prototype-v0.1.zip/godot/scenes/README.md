# Scenes

Place Godot scenes here.

Suggested future structure:

- `player/`
- `enemies/`
- `world/`
- `dungeons/`
- `building/`
- `ui/`

Keep scenes small and focused. Avoid turning one scene into the whole game.
